import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Vellore Truck Transport & Packers Movers | LOADZY",
  description:
    "Book truck transport in Vellore for full load, part load, house shifting, packers and movers, commercial and industrial goods across Tamil Nadu and South India.",
  keywords: [
    "Vellore truck transport",
    "Vellore lorry transport",
    "Vellore packers movers",
    "truck booking Vellore",
    "Vellore freight transport",
    "house shifting Vellore",
    "LOADZY",
  ],
  alternates: {
    canonical: "https://www.loadzyinfra.in/vellore-transport",
  },
};

const services = [
  ["Full Load Transport", "/full-load"],
  ["Part Load Transport", "/part-load"],
  ["House Shifting", "/house-shifting"],
  ["Packers & Movers", "/packers-movers"],
  ["Commercial Transport", "/commercial-transport"],
  ["Industrial Transport", "/industrial-transport"],
  ["Fruits & Vegetables", "/fruits-vegetables"],
  ["Truck Booking", "/load-search"],
];

const routes = [
  ["Vellore → Chennai", "/routes/vellore/chennai"],
  ["Vellore → Bangalore", "/routes/vellore/bangalore"],
  ["Vellore → Tirupati", "/routes/vellore/tirupati"],
  ["Vellore → Vaniyambadi", "/routes/vellore/vaniyambadi"],
  ["Vellore → Ambur", "/routes/vellore/ambur"],
  ["Vellore → Tirupattur", "/routes/vellore/tirupattur"],
  
  ["Chennai → Vellore", "/routes/chennai/vellore"],
  ["Bangalore → Vellore", "/routes/bangalore/vellore"],
  ["Tirupati → Vellore", "/routes/tirupati/vellore"],
  ["Vaniyambadi → Vellore", "/routes/vaniyambadi/vellore"],
  ["Ambur → Vellore", "/routes/ambur/vellore"],
  ["Tirupattur → Vellore", "/routes/tirupattur/vellore"],
];

const faqs = [
  {
    q: "Can I book a truck from Vellore?",
    a: "Yes. LOADZY helps customers find suitable truck transport based on pickup, delivery, load and truck requirements.",
  },
  {
    q: "Does LOADZY provide house shifting from Vellore?",
    a: "Yes. LOADZY supports household shifting and other truck transport requirements.",
  },
  {
    q: "Can I book full load and part load trucks?",
    a: "Yes. LOADZY supports both full load and part load transport requirements.",
  },
  {
    q: "Can Vellore trucks transport goods to Bangalore?",
    a: "Yes. LOADZY supports transport routes connecting Vellore with Bangalore and other South Indian destinations, subject to truck availability.",
  },
];

export default function VelloreTransportPage() {
  const schema = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          {
            "@type": "ListItem",
            position: 1,
            name: "Home",
            item: "https://www.loadzyinfra.in/",
          },
          {
            "@type": "ListItem",
            position: 2,
            name: "Vellore Truck Transport",
            item: "https://www.loadzyinfra.in/vellore-transport",
          },
        ],
      },
      {
        "@type": "Service",
        name: "Vellore Truck Transport Services",
        provider: {
          "@type": "Organization",
          name: "LOADZY",
        },
        areaServed: "Vellore",
        serviceType: "Truck Transport",
      },
      {
        "@type": "FAQPage",
        mainEntity: faqs.map((faq) => ({
          "@type": "Question",
          name: faq.q,
          acceptedAnswer: {
            "@type": "Answer",
            text: faq.a,
          },
        })),
      },
    ],
  };

  return (
    <main className="bg-white text-[#062B55]">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(schema),
        }}
      />

      <section className="bg-[#10182D] px-6 py-20 text-white">
        <div className="mx-auto max-w-6xl">
          <p className="text-sm font-black uppercase tracking-[0.18em] text-[#08A99F]">
            LOADZY VELLORE
          </p>

          <h1 className="mt-5 max-w-4xl text-5xl font-black leading-tight md:text-6xl">
            Vellore Truck Transport & Packers Movers
          </h1>

          <p className="mt-6 max-w-3xl text-lg font-bold leading-8 text-slate-200">
            Truck transport from Vellore for house shifting, packers and
            movers, commercial goods, industrial loads, full load and part
            load requirements across Tamil Nadu and South India.
          </p>

          <div className="mt-8 flex flex-wrap gap-4">
            <Link
              href="/load-search"
              className="rounded-xl bg-yellow-400 px-7 py-4 font-black text-slate-900"
            >
              Find My Truck →
            </Link>

            <Link
              href="/truck-guide"
              className="rounded-xl border border-white/30 px-7 py-4 font-black"
            >
              Truck Guide
            </Link>
          </div>
        </div>
      </section>

      <section className="px-6 py-14">
        <div className="mx-auto max-w-6xl">
          <h2 className="text-4xl font-black">
            Truck Transport Services in Vellore
          </h2>

          <p className="mt-5 max-w-5xl text-lg font-bold leading-8 text-slate-600">
            Vellore is an important transport hub in northern Tamil Nadu,
            connecting Chennai, Bangalore, Tirupati and nearby districts.
            LOADZY helps customers plan truck transport according to pickup,
            delivery, cargo and vehicle requirements.
          </p>

          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {services.map(([name, href]) => (
              <Link
                key={href}
                href={href}
                className="rounded-2xl border border-slate-200 p-6 font-black shadow-sm hover:border-[#08A99F] hover:bg-teal-50"
              >
                {name} →
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 py-14">
        <div className="mx-auto max-w-6xl">
          <p className="text-sm font-black uppercase tracking-[0.18em] text-[#08A99F]">
            ABOUT VELLORE
          </p>

          <h2 className="mt-3 text-3xl font-black md:text-4xl">
            Vellore: Local Economy, Industries and Goods Transport
          </h2>

          <div className="mt-6 max-w-5xl space-y-5 text-lg font-bold leading-8 text-slate-600">
            <p>
              Vellore is an important urban and commercial centre in northern
              Tamil Nadu. Its regional road connections link businesses,
              traders, manufacturers and households with Chennai, Bengaluru,
              Tirupati and other destinations. These connections support the
              movement of goods within the district and across state borders.
            </p>

            <p>
              Healthcare and education are important parts of Vellore's
              economy, alongside retail trade, food businesses, construction,
              small enterprises and manufacturing-related activities.
              Businesses in these sectors may need transport for supplies,
              equipment, packaged goods, furniture and other commercial
              consignments.
            </p>

            <p>
              The wider Vellore district also includes trading centres,
              agricultural activity, leather-related businesses and small
              industrial enterprises. Transport requirements vary by location
              and cargo, from agricultural produce and shop merchandise to
              raw materials, machinery and finished products.
            </p>

            <p>
              LOADZY helps businesses, traders, manufacturers, farmers and
              households submit transport enquiries for full loads, part
              loads, commercial goods and household shifting. Customers
              should provide accurate pickup and delivery addresses, cargo
              details, load dimensions and preferred dates so suitable truck
              options can be explored.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-slate-50 px-6 py-14">
        <div className="mx-auto max-w-6xl">
          <h2 className="text-4xl font-black">
            Popular Truck Routes from Vellore
          </h2>

          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {routes.map(([name, href]) => (
              <Link
                key={href}
                href={href}
                className="rounded-xl border border-slate-200 bg-white p-5 font-black shadow-sm hover:border-[#08A99F]"
              >
                {name} →
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 py-14">
        <div className="mx-auto max-w-5xl">
          <h2 className="text-4xl font-black">
            Why Choose LOADZY for Vellore Transport?
          </h2>

          <div className="mt-8 grid gap-4 sm:grid-cols-2">
            {[
              "Multiple truck types",
              "Full load and part load options",
              "House shifting support",
              "Commercial and industrial transport",
              "Tamil Nadu and South India routes",
              "Route-based truck matching",
              "Affordable freight options",
              "Pickup and delivery planning",
            ].map((item) => (
              <div
                key={item}
                className="rounded-xl border border-slate-200 p-5 font-bold shadow-sm"
              >
                ✓ {item}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="px-6 py-14">
        <div className="mx-auto max-w-6xl">
          <p className="text-sm font-black uppercase tracking-[0.18em] text-[#08A99F]">
            NEARBY LOCATIONS
          </p>

          <h2 className="mt-3 text-3xl font-black md:text-4xl">
            Nearby Areas We Serve from Vellore
          </h2>

          <p className="mt-5 max-w-5xl text-lg font-bold leading-8 text-slate-600">
            LOADZY supports truck transport enquiries from Vellore and nearby
            towns for household shifting, commercial goods, full loads and
            part loads. Select a location below to explore its transport page.
          </p>

          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">

{[
  ["Katpadi", "/katpadi-transport"],
  ["Gudiyatham", "/gudiyatham-transport"],
  ["Anaicut", "/anaicut-transport"],
  ["Pernambut", "/pernambut-transport"],
  ["K. V. Kuppam", "/kv-kuppam-transport"],
  ["Vaniyambadi", "/vaniyambadi-transport"],
  ["Ambur", "/ambur-transport"],
  ["Tirupattur", "/tirupattur-transport"],
  ["Jolarpettai", "/jolarpettai-transport"],
  ["Natrampalli", "/natrampalli-transport"],
  ["Alangayam", "/alangayam-transport"],
  ["Ranipet", "/ranipet-transport"],
  ["Kanchipuram", "/kanchipuram-transport"],
  ["Chittoor", "/chittoor-transport"],
].map(([name, href]) => (
              <Link
                key={href}
                href={href}
                className="rounded-xl border border-slate-200 bg-white p-5 font-black shadow-sm hover:border-[#08A99F] hover:bg-teal-50"
              >
                {name} Transport →
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-slate-50 px-6 py-14">
        <div className="mx-auto max-w-5xl">
          <h2 className="text-4xl font-black">
            Vellore Truck Transport FAQs
          </h2>

          <div className="mt-8 space-y-4">
            {faqs.map((faq) => (
              <details
                key={faq.q}
                className="rounded-2xl border border-slate-200 bg-white p-6"
              >
                <summary className="cursor-pointer text-lg font-black">
                  {faq.q}
                </summary>

                <p className="mt-4 font-bold leading-7 text-slate-600">
                  {faq.a}
                </p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-[#062B55] px-6 py-16 text-center text-white">
        <h2 className="text-4xl font-black">
          Need a Truck from Vellore?
        </h2>

        <p className="mx-auto mt-5 max-w-2xl text-lg font-bold text-white/90">
          Enter your pickup, delivery and load details to find the right truck
          for your transport requirement.
        </p>

        <Link
          href="/load-search"
          className="mt-8 inline-block rounded-xl bg-yellow-400 px-8 py-4 font-black text-slate-900"
        >
          Find My Truck →
        </Link>
      </section>
    </main>
  );
}