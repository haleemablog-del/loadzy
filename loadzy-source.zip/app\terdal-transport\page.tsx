import type { Metadata } from "next";
import Link from "next/link";
import TransportEnquiryForm from "./TransportEnquiryForm";

const SITE_URL = "https://www.loadzyinfra.in";
const PAGE_URL = `${SITE_URL}/terdal-transport`;

export const metadata: Metadata = {
  title: "Terdal Transport Service | Truck Booking | LOADZY",
  description:
    "Find goods transport and truck booking in Terdal, Karnataka. Enquire about agricultural produce, textiles, full load, part load, commercial goods and household shifting with LOADZY.",
  keywords: [
    "Terdal transport service",
    "Terdal truck booking",
    "Terdal goods transport",
    "Terdal lorry booking",
    "Terdal logistics",
    "Terdal agricultural transport",
    "Terdal textile transport",
    "Terdal full load transport",
    "Terdal part load transport",
    "Terdal to Bangalore transport",
    "Terdal to Bengaluru truck booking",
    "Terdal to Bagalkote transport",
    "Karnataka goods transport",
    "LOADZY transport",
  ],
  alternates: { canonical: PAGE_URL },
  openGraph: {
    title: "Terdal Transport Service | LOADZY",
    description:
      "Submit a truck booking enquiry for agricultural, textile and commercial goods transport from Terdal, Karnataka.",
    url: PAGE_URL,
    siteName: "LOADZY",
    locale: "en_IN",
    type: "website",
  },
  robots: { index: true, follow: true },
};

const services = [
  {
    icon: "🚛",
    title: "Full Load Transport",
    description:
      "Enquire about dedicated truck options for larger agricultural, commercial and other consignments.",
    href: "/full-load",
  },
  {
    icon: "📦",
    title: "Part Load Transport",
    description:
      "Explore transport options for smaller consignments that may not need an entire truck.",
    href: "/part-load",
  },
  {
    icon: "🏠",
    title: "House Shifting",
    description:
      "Plan transport for furniture, appliances, cartons and household belongings.",
    href: "/house-shifting",
  },
  {
    icon: "🧰",
    title: "Packers and Movers",
    description:
      "Enquire about vehicle arrangements for household and office relocation.",
    href: "/packers-movers",
  },
  {
    icon: "🏪",
    title: "Commercial Transport",
    description:
      "Move shop stock, packaged goods, textiles and business consignments.",
    href: "/commercial-transport",
  },
  {
    icon: "🏭",
    title: "Industrial Transport",
    description:
      "Enquire about transporting machinery, industrial materials and business supplies.",
    href: "/industrial-transport",
  },
];

const destinations = [
  "Bengaluru",
  "Hubballi",
  "Belagavi",
  "Vijayapura",
  "Bagalkote",
  "Dharwad",
  "Mysuru",
  "Mangaluru",
  "Davangere",
  "Haveri",
  "Kalaburagi",
  "Ballari",
];

const nearbyTowns = [
  {
    name: "Terdal",
    slug: "terdal",
    famousFor: "Agricultural activity and textile-related trade",
    goods:
      "Agricultural produce, textiles, shop stock, packaged goods and commercial cargo.",
  },
  {
    name: "Rabkavi Banhatti",
    slug: "rabkavi-banhatti",
    famousFor: "Textile trade and weaving-related commerce",
    goods:
      "Textiles, fabric bundles, clothing materials and business consignments.",
  },
  {
    name: "Mahalingpur",
    slug: "mahalingpur",
    famousFor: "Textile-related trade and regional commerce",
    goods:
      "Textiles, fabric consignments, agricultural produce and business stock.",
  },
  {
    name: "Jamkhandi",
    slug: "jamkhandi",
    famousFor: "Agriculture and regional commercial activity",
    goods:
      "Agricultural produce, packaged goods, shop stock and general cargo.",
  },
  {
    name: "Mudhol",
    slug: "mudhol",
    famousFor: "Agriculture and local industries",
    goods:
      "Agricultural goods, industrial supplies, commercial materials and general cargo.",
  },
  {
    name: "Bagalkote",
    slug: "bagalkote",
    famousFor: "District headquarters and commercial activity",
    goods:
      "Commercial goods, construction materials, business stock and general cargo.",
  },
  {
    name: "Ilkal",
    slug: "ilkal",
    famousFor: "Traditional Ilkal sarees and textile trade",
    goods:
      "Sarees, textiles, garment consignments and packaged merchandise.",
  },
  {
    name: "Guledgudda",
    slug: "guledgudda",
    famousFor: "Traditional textile and handloom products",
    goods:
      "Textiles, handloom products, clothing consignments and business supplies.",
  },
  {
    name: "Bilgi",
    slug: "bilgi",
    famousFor: "Agriculture and local trade",
    goods:
      "Agricultural goods, commercial supplies and general transport consignments.",
  },
];

const faqs = [
  {
    question: "How can I book a truck in Terdal?",
    answer:
      "Fill in the transport enquiry form with your name, phone number, pickup and delivery locations, service, truck type and preferred pickup date. Submit your enquiry and confirm vehicle availability and freight charges before finalising your booking.",
  },
  {
    question: "Can I transport agricultural goods from Terdal?",
    answer:
      "You can enquire about transporting suitable agricultural produce and related commercial goods. Share the cargo description, quantity, packaging, pickup address and destination so the transport requirements can be assessed.",
  },
  {
    question: "Can I enquire about textile transport from Terdal?",
    answer:
      "You can submit enquiries for suitable textile consignments, fabric bundles and commercial goods. The vehicle and handling requirements depend on the shipment details.",
  },
  {
    question: "Is full load transport available from Terdal?",
    answer:
      "You can enquire about full load transport. Suitable truck size, availability and freight charges depend on the cargo, route and pickup date.",
  },
  {
    question: "Can I book part load transport?",
    answer:
      "You can enquire about part load transport for smaller consignments. Availability depends on the route, load size, timing and suitable transport options.",
  },
  {
    question: "Can I book a truck from Terdal to Bengaluru?",
    answer:
      "You can submit an enquiry for Terdal to Bengaluru transport. Vehicle availability, freight quotation and pickup schedule must be confirmed for your shipment.",
  },
  {
    question: "How are freight charges calculated?",
    answer:
      "Freight charges may depend on distance, vehicle type, load weight and dimensions, loading requirements, pickup date and availability. Confirm the final quotation before booking.",
  },
  {
    question: "Does an enquiry guarantee a truck?",
    answer:
      "No. Submitting an enquiry does not automatically confirm a vehicle or price. Truck availability, freight charges and pickup arrangements must be confirmed separately.",
  },
];

const serviceSchema = {
  "@context": "https://schema.org",
  "@type": "Service",
  name: "Terdal Goods Transport and Truck Booking",
  description:
    "Transport enquiries for agricultural produce, textiles, full load, part load, commercial goods and household shifting from Terdal, Karnataka.",
  serviceType: [
    "Agricultural goods transport",
    "Textile transport",
    "Full load transport",
    "Part load transport",
    "Commercial goods transport",
    "Household shifting transport",
  ],
  url: PAGE_URL,
  provider: {
    "@type": "Organization",
    name: "LOADZY",
    url: SITE_URL,
  },
  areaServed: {
    "@type": "Place",
    name: "Terdal, Karnataka, India",
  },
};

const breadcrumbSchema = {
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  itemListElement: [
    {
      "@type": "ListItem",
      position: 1,
      name: "Home",
      item: SITE_URL,
    },
    {
      "@type": "ListItem",
      position: 2,
      name: "Terdal Transport",
      item: PAGE_URL,
    },
  ],
};

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: faq.answer,
    },
  })),
};

export default function TerdalTransportPage() {
  return (
    <main className="min-h-screen bg-white text-slate-800">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(serviceSchema).replace(/</g, "\\u003c"),
        }}
      />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(breadcrumbSchema).replace(/</g, "\\u003c"),
        }}
      />

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(faqSchema).replace(/</g, "\\u003c"),
        }}
      />

      {/* HERO */}
      <section className="relative overflow-hidden bg-[#10182D] text-white">
        <div className="absolute -right-24 -top-24 h-80 w-80 rounded-full bg-[#08A99F]/20 blur-3xl" />
        <div className="absolute -bottom-24 -left-20 h-72 w-72 rounded-full bg-yellow-400/10 blur-3xl" />

        <div className="relative mx-auto grid max-w-7xl gap-12 px-5 py-16 md:grid-cols-2 md:items-center md:px-8 md:py-20">
          <div>
            <nav
              aria-label="Breadcrumb"
              className="mb-7 text-sm text-slate-300"
            >
              <Link href="/" className="hover:text-teal-300">
                Home
              </Link>
              <span className="mx-2">/</span>
              <span>Terdal Transport</span>
            </nav>

            <p className="inline-flex rounded-full border border-[#08A99F]/40 bg-[#08A99F]/10 px-4 py-2 text-sm font-bold tracking-wider text-teal-300">
              MOVE. CONNECT. DELIVER.
            </p>

            <h1 className="mt-5 text-4xl font-extrabold leading-tight tracking-tight md:text-6xl">
              Terdal Transport Service
              <span className="mt-3 block text-[#08A99F]">
                Truck Booking Made Easier
              </span>
            </h1>

            <p className="mt-6 max-w-xl text-base leading-8 text-slate-300 md:text-lg">
              Looking for goods transport in Terdal, Karnataka? Enquire with
              LOADZY about agricultural produce, textiles, full load, part
              load, commercial goods, industrial transport and household
              shifting for local and intercity routes.
            </p>

            <div className="mt-8 flex flex-col gap-4 sm:flex-row">
              <Link
                href="/contact"
                className="inline-flex items-center justify-center rounded-xl bg-yellow-400 px-7 py-4 font-bold text-slate-950 transition hover:bg-yellow-300"
              >
                Book a Truck →
              </Link>

              <Link
                href="/contact"
                className="inline-flex items-center justify-center rounded-xl border border-white/25 px-7 py-4 font-semibold text-white transition hover:border-[#08A99F] hover:bg-white/5"
              >
                Get Your Transport Price
              </Link>
            </div>

            <div className="mt-8 flex flex-wrap gap-3 text-sm text-slate-300">
              {[
                "Agricultural Goods",
                "Textile Transport",
                "Full Load",
                "Part Load",
              ].map((item) => (
                <span
                  key={item}
                  className="rounded-full bg-white/10 px-4 py-2"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>

          <TransportEnquiryForm />
        </div>
      </section>

      {/* SERVICES */}
      <section className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-20">
        <p className="font-bold uppercase tracking-[0.18em] text-[#08A99F]">
          Transport solutions
        </p>

        <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl">
          Goods Transport Services in Terdal
        </h2>

        <p className="mt-4 max-w-3xl leading-7 text-slate-600">
          Explore transport options for agricultural produce, textiles,
          household goods, shop stock and commercial consignments. Share your
          route and load requirements to enquire about a suitable vehicle.
        </p>

        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service) => (
            <Link
              key={service.title}
              href={service.href}
              className="group rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:border-[#08A99F] hover:shadow-lg"
            >
              <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-teal-50 text-3xl">
                {service.icon}
              </span>

              <h3 className="mt-5 text-xl font-bold text-slate-900 group-hover:text-teal-700">
                {service.title}
              </h3>

              <p className="mt-3 leading-7 text-slate-600">
                {service.description}
              </p>

              <span className="mt-5 inline-flex font-bold text-teal-700">
                Explore service →
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* LOCAL INFORMATION */}
      <section className="bg-slate-50">
        <div className="mx-auto grid max-w-7xl gap-10 px-5 py-16 md:grid-cols-2 md:items-start md:px-8 md:py-20">
          <div>
            <p className="font-bold uppercase tracking-[0.18em] text-[#08A99F]">
              Local transport
            </p>

            <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl">
              Transport and Truck Booking in Terdal, Karnataka
            </h2>

            <p className="mt-5 leading-8 text-slate-600">
              Terdal and the surrounding Bagalkote region have agricultural
              activity and local commercial trade. Depending on the shipment,
              transport requirements may include agricultural produce,
              textiles, packaged merchandise, shop stock and general goods.
            </p>

            <p className="mt-4 leading-8 text-slate-600">
              When requesting a truck, provide the exact pickup and delivery
              addresses, goods description, approximate weight and dimensions,
              packaging and loading requirements, and preferred pickup date.
              These details help determine suitable vehicle requirements and a
              freight quotation.
            </p>

            <p className="mt-4 leading-8 text-slate-600">
              LOADZY accepts transport enquiries for local and intercity
              movement. Vehicle availability, rates and schedules depend on
              each booking and must be confirmed before transport.
            </p>
          </div>

          <div className="rounded-3xl bg-[#10182D] p-7 text-white md:p-9">
            <h3 className="text-2xl font-bold">Prepare Before Booking</h3>

            <ul className="mt-6 space-y-4">
              {[
                "Pickup and delivery addresses",
                "Goods description and approximate load size",
                "Required truck type or capacity",
                "Preferred pickup date",
                "Loading and unloading requirements",
                "Contact details for confirmation",
              ].map((item) => (
                <li
                  key={item}
                  className="flex gap-3 leading-6 text-slate-200"
                >
                  <span className="font-bold text-[#08A99F]">✓</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>

            <Link
              href="/contact"
              className="mt-8 inline-flex w-full items-center justify-center rounded-xl bg-yellow-400 px-6 py-4 font-bold text-slate-950 transition hover:bg-yellow-300"
            >
              Get Your Transport Price →
            </Link>
          </div>
        </div>
      </section>

      {/* FAMOUS FOR AND GOODS */}
      <section className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-20">
        <p className="font-bold uppercase tracking-[0.18em] text-[#08A99F]">
          Local specialities
        </p>

        <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl">
          What Is Terdal Known For?
        </h2>

        <p className="mt-4 max-w-3xl leading-7 text-slate-600">
          Terdal is associated with agricultural activity and regional
          commerce, with textile-related trade also relevant in the surrounding
          area. Transport enquiries can cover suitable agricultural produce,
          textile consignments, packaged goods and business stock. Confirm
          the exact goods and handling needs before choosing a vehicle.
        </p>

        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {[
            {
              icon: "🌾",
              title: "Agricultural Produce",
              text: "Enquire about suitable vehicles for farm produce and related goods.",
            },
            {
              icon: "🧵",
              title: "Textiles and Fabrics",
              text: "Share package quantity and details for textile consignments.",
            },
            {
              icon: "📦",
              title: "Packaged Goods",
              text: "Provide cargo dimensions and packaging information.",
            },
            {
              icon: "🏪",
              title: "Commercial Stock",
              text: "Explore transport options for shop supplies and business goods.",
            },
          ].map((item) => (
            <div
              key={item.title}
              className="rounded-2xl border border-slate-200 bg-white p-6"
            >
              <span className="text-3xl" aria-hidden="true">
                {item.icon}
              </span>
              <h3 className="mt-4 text-lg font-bold text-slate-900">
                {item.title}
              </h3>
              <p className="mt-3 leading-7 text-slate-600">{item.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* NEARBY TOWNS */}
      <section className="bg-slate-50">
        <div className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-20">
          <p className="font-bold uppercase tracking-[0.18em] text-[#08A99F]">
            Local coverage
          </p>

          <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl">
            Truck Transport in Terdal and Nearby Towns
          </h2>

          <p className="mt-4 max-w-3xl leading-7 text-slate-600">
            Explore transport information for Terdal and nearby locations in
            the Bagalkote region. Select a location to open its transport page
            and enquire about your route.
          </p>

          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {nearbyTowns.map((town) => (
              <Link
                key={town.slug}
                href={`/${town.slug}-transport`}
                className="group rounded-2xl border border-slate-200 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:border-[#08A99F] hover:shadow-lg"
              >
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-xl font-bold text-slate-900 group-hover:text-teal-700">
                    {town.name} Transport
                  </h3>
                  <span className="text-xl text-[#08A99F]">↗</span>
                </div>

                <p className="mt-3 text-sm font-semibold text-teal-700">
                  Famous for: {town.famousFor}
                </p>

                <p className="mt-3 leading-7 text-slate-600">
                  Transport goods: {town.goods}
                </p>

                <span className="mt-5 inline-flex font-bold text-teal-700">
                  Explore {town.name} →
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* DESTINATIONS */}
      <section className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-20">
        <p className="font-bold uppercase tracking-[0.18em] text-[#08A99F]">
          Intercity transport
        </p>

        <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl">
          Major Destinations from Terdal
        </h2>

        <p className="mt-4 max-w-3xl leading-7 text-slate-600">
          Planning to move goods from Terdal to another city? Select a
          destination to submit a transport enquiry. Route coverage, vehicle
          availability and freight charges must be confirmed for each shipment.
        </p>

        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
          {destinations.map((city) => (
            <Link
              key={city}
              href="/contact"
              className="group flex items-center justify-between rounded-xl border border-slate-200 bg-white px-4 py-4 transition hover:border-[#08A99F] hover:bg-teal-50"
            >
              <span className="font-semibold text-slate-800 group-hover:text-teal-800">
                Terdal to {city}
              </span>
              <span className="ml-2 text-[#08A99F]">→</span>
            </Link>
          ))}
        </div>
      </section>

      {/* WHY LOADZY */}
      <section className="bg-slate-50">
        <div className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-20">
          <div className="mx-auto max-w-3xl text-center">
            <p className="font-bold uppercase tracking-[0.18em] text-[#08A99F]">
              Why LOADZY
            </p>

            <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl">
              A Simpler Way to Explore Transport Options
            </h2>

            <p className="mt-4 leading-7 text-slate-600">
              Share your shipment details, enquire about suitable vehicle
              options and confirm the arrangements for your route.
            </p>
          </div>

          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                icon: "📍",
                title: "Route Enquiries",
                text: "Share pickup and delivery details for your shipment.",
              },
              {
                icon: "🚚",
                title: "Truck Options",
                text: "Enquire about vehicle types for your cargo requirements.",
              },
              {
                icon: "🌾",
                title: "Agricultural Goods",
                text: "Provide cargo details and any special handling needs.",
              },
              {
                icon: "💬",
                title: "Clear Requirements",
                text: "Share load details to help confirm suitable transport.",
              },
            ].map((item) => (
              <div
                key={item.title}
                className="rounded-2xl border border-slate-200 bg-white p-6"
              >
                <span className="text-3xl" aria-hidden="true">
                  {item.icon}
                </span>
                <h3 className="mt-4 text-lg font-bold text-slate-900">
                  {item.title}
                </h3>
                <p className="mt-3 leading-7 text-slate-600">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* BOOKING STEPS */}
      <section className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-20">
        <p className="font-bold uppercase tracking-[0.18em] text-[#08A99F]">
          How it works
        </p>

        <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl">
          How to Request Transport from Terdal
        </h2>

        <div className="mt-9 grid gap-5 md:grid-cols-4">
          {[
            {
              number: "01",
              title: "Enter Locations",
              text: "Provide pickup and delivery addresses.",
            },
            {
              number: "02",
              title: "Share Load Details",
              text: "Choose your service, truck type and pickup date.",
            },
            {
              number: "03",
              title: "Submit Enquiry",
              text: "Send your booking details through the enquiry form.",
            },
            {
              number: "04",
              title: "Confirm Details",
              text: "Confirm availability, freight charges and timing.",
            },
          ].map((step) => (
            <div
              key={step.number}
              className="rounded-2xl border border-slate-200 bg-white p-6"
            >
              <p className="text-sm font-extrabold tracking-widest text-[#08A99F]">
                STEP {step.number}
              </p>
              <h3 className="mt-4 text-xl font-bold text-slate-900">
                {step.title}
              </h3>
              <p className="mt-3 leading-7 text-slate-600">{step.text}</p>
            </div>
          ))}
        </div>

        <div className="mt-9 text-center">
          <Link
            href="/contact"
            className="inline-flex items-center justify-center rounded-xl bg-[#08A99F] px-8 py-4 font-bold text-white transition hover:bg-teal-700"
          >
            Get Your Transport Price →
          </Link>
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-slate-50">
        <div className="mx-auto max-w-4xl px-5 py-16 md:px-8 md:py-20">
          <div className="text-center">
            <p className="font-bold uppercase tracking-[0.18em] text-[#08A99F]">
              FAQs
            </p>

            <h2 className="mt-3 text-3xl font-bold tracking-tight text-slate-900 md:text-4xl">
              Terdal Transport — Frequently Asked Questions
            </h2>
          </div>

          <div className="mt-9 space-y-4">
            {faqs.map((faq) => (
              <details
                key={faq.question}
                className="group rounded-xl border border-slate-200 bg-white p-5"
              >
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-bold text-slate-900">
                  <span>{faq.question}</span>
                  <span className="text-xl text-[#08A99F] transition group-open:rotate-45">
                    +
                  </span>
                </summary>

                <p className="mt-4 leading-7 text-slate-600">{faq.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="bg-[#10182D] px-5 py-16 text-white md:px-8 md:py-20">
        <div className="mx-auto max-w-5xl text-center">
          <p className="font-bold uppercase tracking-[0.18em] text-teal-300">
            LOADZY Transport
          </p>

          <h2 className="mt-4 text-3xl font-extrabold leading-tight md:text-5xl">
            Looking for Goods Transport from Terdal?
          </h2>

          <p className="mx-auto mt-5 max-w-2xl leading-8 text-slate-300">
            Share your pickup location, destination and load requirements to
            enquire about suitable transport options for your shipment.
          </p>

          <div className="mt-8 flex flex-col justify-center gap-4 sm:flex-row">
            <Link
              href="/contact"
              className="inline-flex items-center justify-center rounded-xl bg-yellow-400 px-8 py-4 font-bold text-slate-950 transition hover:bg-yellow-300"
            >
              Get Your Transport Price →
            </Link>

            <Link
              href="/"
              className="inline-flex items-center justify-center rounded-xl border border-white/25 px-8 py-4 font-semibold text-white transition hover:border-[#08A99F] hover:bg-white/5"
            >
              Back to LOADZY Home
            </Link>
          </div>

          <p className="mt-6 text-sm text-slate-400">
            LOADZY — MOVE. CONNECT. DELIVER.
          </p>
        </div>
      </section>
    </main>
  );
}